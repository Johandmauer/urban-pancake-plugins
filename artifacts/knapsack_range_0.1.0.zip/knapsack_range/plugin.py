from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Tuple


def _parse_number_list(text: str, cast_fn):
    # Accept commas/spaces/newlines
    raw = text.replace(',', ' ').replace(';', ' ').split()
    if not raw:
        return []
    return [cast_fn(x) for x in raw]


def _compute_ranges(
    prices: List[float],
    min_counts_in: List[int],
    max_counts_in: List[int],
    min_sum: float,
    max_sum: float,
) -> List[Tuple[float, float, List[int], Tuple[int, int]]]:
    """Adapted from the user's main.py: enumerate combinations of counts for items 0..n-2
    and compute possible range for last item so total is within [min_sum, max_sum].

    Returns list of tuples:
      (total_min, total_max, fixed_counts_for_first_n_minus_1, (last_min, last_max))
    """
    n = len(prices)
    if n == 0:
        return []
    if not (len(min_counts_in) == len(max_counts_in) == n):
        raise ValueError("min_counts/max_counts length must match prices length")

    # Ensure sane bounds
    if min_sum > max_sum:
        raise ValueError("min_sum > max_sum")

    # Handle zero prices safely
    sum_prices = sum(prices)
    delta_price = max_sum - sum_prices
    possible_max_by_sum = [
        int((delta_price + prices[i]) // (prices[i] + (prices[i] == 0))) * (prices[i] != 0)
        for i in range(n)
    ]

    max_counts = [min(possible_max_by_sum[i], max(max_counts_in[i], 1)) for i in range(n)]
    min_counts = [min(max(1, min(min_counts_in[i], possible_max_by_sum[i])), max_counts[i]) for i in range(n)]

    if sum(prices[i] * min_counts[i] for i in range(n)) > max_sum:
        return []
    if sum(prices[i] * max_counts[i] for i in range(n)) < min_sum:
        return []

    last = n - 1
    base_counts = min_counts.copy()

    # Work sum for items 0..last-1
    work_sum = sum(prices[i] * base_counts[i] for i in range(last))

    results: List[Tuple[float, float, List[int], Tuple[int, int]]] = []

    # Iterate over combinations for first n-1 items, like in original script.
    expr = True
    while expr:
        delta_max = max_sum - work_sum
        delta_min = min_sum - work_sum

        # Range for last item
        p_last = prices[last]
        if p_last == 0:
            last_min = min_counts[last]
            last_max = max_counts[last]
        else:
            last_min = int(delta_min // p_last + 1)
            last_max = int(delta_max // p_last)

            if last_min > last_max:
                last_min = last_max

            if last_min < min_counts[last]:
                last_min = min_counts[last]
            if last_max > max_counts[last]:
                last_max = max_counts[last]

        total_min = work_sum + last_min * p_last
        total_max = work_sum + last_max * p_last

        if last_min <= last_max and (total_min <= max_sum) and (total_max >= min_sum):
            # clamp totals within requested bounds for display
            disp_min = max(min_sum, total_min)
            disp_max = min(max_sum, total_max)
            results.append((disp_min, disp_max, base_counts[:last].copy(), (last_min, last_max)))

        # Next combination step (increment from right to left)
        advanced = False
        for k in range(last - 1, -1, -1):
            base_counts[k] += 1
            work_sum += prices[k]

            if base_counts[k] > max_counts[k] or work_sum > max_sum:
                if k == 0:
                    expr = False
                    break
                # reset this position to min
                work_sum -= prices[k] * (base_counts[k] - min_counts[k])
                base_counts[k] = min_counts[k]
                continue
            else:
                advanced = True
                break
        if not advanced and expr:
            # no further advancement possible
            expr = False

    return results


@dataclass
class Plugin:
    def meta(self) -> Dict[str, Any]:
        return {
            "id": "knapsack_range",
            "name": "Рюкзак (подбор сумм по диапазону)",
            "version": "0.1.0",
            "description": "Подбирает возможные количества товаров так, чтобы итоговая сумма попала в диапазон.\nАдаптировано из вашего main.py.",
            "api_version": 1,
        }

    def ui_schema(self) -> Dict[str, Any]:
        return {
            "title": "Рюкзак",
            "fields": [
                {
                    "type": "float",
                    "key": "min_sum",
                    "label": "Минимальная сумма",
                    "default": 1000,
                },
                {
                    "type": "float",
                    "key": "max_sum",
                    "label": "Максимальная сумма",
                    "default": 1005,
                },
                {
                    "type": "multiline",
                    "key": "prices",
                    "label": "Цены (через пробел/запятую)",
                    "default": "27.5, 159, 112, 140",
                    "help": "Пример: 27.5, 159, 112, 140",
                },
                {
                    "type": "multiline",
                    "key": "min_counts",
                    "label": "Мин. количество (по позициям)",
                    "default": "1, 1, 1, 1",
                },
                {
                    "type": "multiline",
                    "key": "max_counts",
                    "label": "Макс. количество (по позициям)",
                    "default": "10, 3, 2, 6",
                },
                {
                    "type": "int",
                    "key": "limit",
                    "label": "Лимит строк вывода",
                    "default": 200,
                    "min": 1,
                    "max": 5000,
                    "help": "Чтобы не забить таблицу тысячами строк.",
                },
            ],
        }

    def run(self, inputs: Dict[str, Any], host) -> List[Dict[str, Any]]:
        min_sum = float(inputs.get("min_sum", 0))
        max_sum = float(inputs.get("max_sum", 0))
        prices = _parse_number_list(str(inputs.get("prices", "")), float)
        min_counts = _parse_number_list(str(inputs.get("min_counts", "")), int)
        max_counts = _parse_number_list(str(inputs.get("max_counts", "")), int)
        limit = int(inputs.get("limit", 200))

        if not prices:
            return [{"type": "error", "value": "Не заданы цены."}]
        n = len(prices)
        if len(min_counts) != n or len(max_counts) != n:
            return [{"type": "error", "value": f"Длины списков не совпадают: prices={n}, min_counts={len(min_counts)}, max_counts={len(max_counts)}"}]

        host.log(f"items: {n}, min_sum={min_sum}, max_sum={max_sum}")

        rows_out = []
        results = _compute_ranges(prices, min_counts, max_counts, min_sum, max_sum)
        host.log(f"ranges found: {len(results)}")

        for i, (tmin, tmax, fixed, last_rng) in enumerate(results[:limit]):
            row = [
                i + 1,
                f"{tmin:.2f}",
                f"{tmax:.2f}",
            ]
            row.extend(fixed)
            row.append(f"{last_rng[0]}..{last_rng[1]}")
            rows_out.append(row)

        columns = ["#", "Total min", "Total max"] + [f"c{i+1}" for i in range(n - 1)] + [f"c{n} (range)"]

        text = (
            "Формат результата: фиксируются количества для первых N-1 позиций,\n"
            "а для последней показывается диапазон количества, при котором итог попадает в [min_sum, max_sum]."
        )

        blocks: List[Dict[str, Any]] = [
            {"type": "text", "title": "Пояснение", "value": text},
            {"type": "text", "title": "Сводка", "value": f"Найдено строк: {len(results)} (показано: {min(len(results), limit)})"},
            {"type": "table", "title": "Варианты", "columns": columns, "rows": rows_out},
        ]

        if len(results) > limit:
            blocks.append({"type": "text", "title": "Примечание", "value": f"Вывод ограничен до {limit} строк. Увеличь лимит, если нужно."})

        return blocks
